'''
Simple Hash Table for Assignment
Core implementation only - h(k,i) = (k + i^3) mod 10
Author: Van Robbins
'''

def main():
    # Initialize hash table of size 10 with -1 in all slots
    hash_table = [-1] * 10
    keys_to_insert = [15, 27, 5, 12, 35]
    
    print("Hash Table Assignment")
    print("Hash Function: h(k,i) = (k + i^3) mod 10")
    print("Keys to insert:", keys_to_insert)
    print("=" * 50)
    
    # Show initial table
    print("\nInitial hash table:")
    print("Index:", [i for i in range(10)])
    print("Value:", hash_table)
    print()
    
    # Insert each key
    for key in keys_to_insert:
        print(f"Inserting {key}:")
        
        # Try different iterations until empty slot found
        inserted = False
        for i in range(10):
            index = (key + i**3) % 10
            print(f"  h({key},{i}) = ({key} + {i}^3) mod 10 = {index}")
            
            if hash_table[index] == -1:
                hash_table[index] = key
                print(f"  Inserted {key} at index {index}")
                inserted = True
                break
            else:
                print(f"  Collision at index {index} (contains {hash_table[index]})")
        
        if not inserted:
            print(f"  Could not insert {key} - table full")
        
        # Show table after insertion
        print("  Table:", hash_table)
        print()
    
    print("Final hash table:")
    print("Index:", [i for i in range(10)])
    print("Value:", hash_table)

if __name__ == "__main__":
    main()
